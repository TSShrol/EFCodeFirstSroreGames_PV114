﻿using DataAccess.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class StoreGamesContext:DbContext
    {
        public StoreGamesContext() { 
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog=StoreGames; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False");
           // optionsBuilder.LogTo(Console.WriteLine);
        }
        //protected internal virtual void OnModelCreating(ModelBuilder modelBuilder) { }
        public DbSet<StyleGame> StyleGames { get; set; }
        public DbSet<Game> Games { get; set; }

    }
}
