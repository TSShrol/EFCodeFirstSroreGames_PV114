﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DataAccess.Migrations
{
    public partial class ModefiedGame : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Games_StyleGames_StyleGameId",
                table: "Games");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Games",
                table: "Games");

            migrationBuilder.RenameTable(
                name: "Games",
                newName: "CompGame");

            migrationBuilder.RenameIndex(
                name: "IX_Games_StyleGameId",
                table: "CompGame",
                newName: "IX_CompGame_StyleGameId");

            migrationBuilder.AlterColumn<string>(
                name: "NameGame",
                table: "CompGame",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_CompGame",
                table: "CompGame",
                column: "id");

            migrationBuilder.AddForeignKey(
                name: "FK_CompGame_StyleGames_StyleGameId",
                table: "CompGame",
                column: "StyleGameId",
                principalTable: "StyleGames",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CompGame_StyleGames_StyleGameId",
                table: "CompGame");

            migrationBuilder.DropPrimaryKey(
                name: "PK_CompGame",
                table: "CompGame");

            migrationBuilder.RenameTable(
                name: "CompGame",
                newName: "Games");

            migrationBuilder.RenameIndex(
                name: "IX_CompGame_StyleGameId",
                table: "Games",
                newName: "IX_Games_StyleGameId");

            migrationBuilder.AlterColumn<string>(
                name: "NameGame",
                table: "Games",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Games",
                table: "Games",
                column: "id");

            migrationBuilder.AddForeignKey(
                name: "FK_Games_StyleGames_StyleGameId",
                table: "Games",
                column: "StyleGameId",
                principalTable: "StyleGames",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
