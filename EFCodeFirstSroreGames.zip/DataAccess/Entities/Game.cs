﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Entities
{
   [Table("CompGame")]
   public class Game
    {
        public int id { get; set; }
      
        [Required]
        [MaxLength(50)]
        public string NameGame { get; set; }
        public string Studio { get; set; }
        public DateTime Release { get; set; }
        //foregin key 
        public int StyleGameId { get; set; }

        //navigetion property
        public StyleGame StyleGame { get; set; }
    }
    
}
